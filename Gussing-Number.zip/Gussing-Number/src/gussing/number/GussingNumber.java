package gussing.number;

import java.util.Scanner;

public class GussingNumber {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int R_number, U_number;
        R_number = (int) (Math.random() * 100);
        System.out.println("What do you think which number I choose it?   ");
        U_number = input.nextInt();
        while (R_number != U_number) {
            if (R_number < U_number) {
                System.out.println("Your Think is higher then my number");
            } else {
                System.out.println("Your Think is lower then my number");
            }
            U_number = input.nextInt();
        }
        System.out.println("!!!!!!!!WOW!!!!!!!!!! \n your think is correct " + " the real number is = "+R_number);
    }

}
