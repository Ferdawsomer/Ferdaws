package an.advance.math.learning.tool;

import java.util.Scanner;

public class AnAdvanceMathLearningTool {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int num1, num2, sub, An_sub, count = 0, C_A = 0;
        while (count < 5) {
            num1 = (int) (Math.random() * 10);
            num2 = (int) (Math.random() * 10);
            if (num1 >= num2) {
                System.out.println("What is the result of : " + num1 + "-" + num2);
                sub = num1 - num2;
                An_sub = input.nextInt();
                if (sub == An_sub) {
                    System.out.println("Your answer is correct   ");
                    C_A++;
                } else {
                    System.out.println("No Your answer isn't correct!");
                }
                count++;
            } else {
            }
        }
        System.out.println("\n\nYou correct " + C_A + " question from 5 question ");
    }
}
