package bmiclass;

public class BMI {
    String status,name;
    int age;
    double w;
    double h;

    public double getBMI() {
        double BMI = w / (h * h);
        return BMI;
    }

    public String getStatus() {
        double BMI = w / (h * h);
        if (BMI >= 30.0) {
            status = "obese";
        } else if (BMI >= 25.0 && BMI < 30.0) {
            status = "overweight";
        } else if (BMI >= 18.5 && BMI < 25.0) {
            status = "normal";
        } else if (BMI < 18.5) {
            status = "underweight";
        }
        return status;
    }

}
