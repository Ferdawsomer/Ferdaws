package bmiclass;

import java.util.Scanner;

public class BMIclass {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        BMI b = new BMI();
        System.out.println("What's your name ? ");
        b.name = input.next();
        System.out.println("Give me your age");
        b.age = input.nextInt();
        System.out.println("Give me your height");
        b.h = input.nextDouble();
        System.out.println("Give me your weight");
        b.w = input.nextDouble();
        System.out.println(b.name + " jan you're " + b.age + "th years old");
        System.out.println("and your BMI average is ==> " + b.getBMI());
        System.out.println("and your Status is ==> " + b.getStatus());

    }

}
