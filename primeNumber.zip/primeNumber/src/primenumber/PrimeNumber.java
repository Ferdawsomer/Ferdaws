package primenumber;

import java.util.Scanner;

public class PrimeNumber {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int number, i, count;
        System.out.println("Enter a number which i check to that prime of compound");
        number = input.nextInt();
        if (number <= 1) {
            System.out.println("please Enter uper number then 1 ");
        } else {
            for (i = 2; i < number; i++) {
                if (number % i == 0) {
                    System.out.println("This number is Compound");
                    return;
                }
            }
            System.out.println("This number is prime");
        }
    }
}
