package monetryunits;

import java.util.Scanner;

public class MonetryUnits {
    public static void main(String[] args) {
        Scanner input=new Scanner(System.in);
        double dollar,quater,dimes,nickls,pennies;
        
        System.out.println("Give me the value of your dollars!");
        dollar=input.nextDouble();
        int indollar=(int)dollar;
        double dedollar=dollar-indollar;
        quater=indollar*4d;System.out.println("the quater is   "+quater);
        dimes=indollar*10d;System.out.println("the dimes is   "+dimes);
        nickls=indollar*100d;System.out.println("the nickls is   "+nickls);
        pennies=dedollar/5d;System.out.println("the pennies is   "+pennies);
    }
}
