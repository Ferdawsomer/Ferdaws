package linersearch;

import java.util.Scanner;

public class LinerSearch {
    public static void main(String[] args) {
        Scanner input =  new Scanner(System.in);
        int [] list = {1,2,3,4,5,6,7,8};
        System.out.println("Which number do you want ? ");
        int want = input.nextInt();
        for (int i = 0; i < list.length; i++) {
            if (list[i] == want) {
                System.out.println("this number is " + i + " here");
                return;
            }
        }
        System.out.println("This number isn't exit in this array");
    }
    
}
