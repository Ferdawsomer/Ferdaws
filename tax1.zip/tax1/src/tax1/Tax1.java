package tax1;

import java.util.Scanner;

public class Tax1 {
    public static void main(String[] args) {

         Scanner SC = new Scanner(System.in);
        double rate,tax,price,mylprice,mytax;
        System.out.println("Give the value of rate");
        rate=SC.nextDouble();
        System.out.println("Give me the value of tax");
        tax= SC.nextDouble();
        System.out.println("Give me your tax");
        mytax=SC.nextDouble();
        price = rate+(rate * (tax)/100);
        
        mylprice= price+(price * (mytax)/100);
        
        System.out.println("The price is ==>  "+price);
        System.out.println("Round off of price is ==>  "+Math.round(price));
        System.out.println("price after my tax is ==>  "+Math.round(mylprice));
    }
    
}
