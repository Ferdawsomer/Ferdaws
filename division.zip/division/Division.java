package division;

import java.util.Scanner;

public class Division {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int number;
        System.out.println("Give me the number!");
        number = input.nextInt();

        if (number % 2 == 0) {
            System.out.println("This number is divisiable by 2");
        }
        if (number % 3 == 0) {
            System.out.println("This number is divisiable by 3");
        } else if (number % 2 != 0 && number % 3 != 0) {
            System.out.println("This number is not divisible by 2 and 3");
        }

    }

}
