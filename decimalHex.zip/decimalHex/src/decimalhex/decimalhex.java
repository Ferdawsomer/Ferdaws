package decimalhex;

import java.util.Scanner;

public class decimalhex {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.print("Enter a decimal value ");
        int decimal = input.nextInt();

        String hex = "";

        int remainder;
        while (decimal > 0) {
            remainder = decimal % 16;

            switch (remainder) {
                case 0:
                    hex = "0" + hex;
                    break;
                case 1:
                    hex = "1" + hex;
                    break;
                case 2:
                    hex = "2" + hex;
                    break;
                case 3:
                    hex = "3" + hex;
                    break;
                case 4:
                    hex = "4" + hex;
                    break;
                case 5:
                    hex = "5" + hex;
                    break;
                case 6:
                    hex = "6" + hex;
                    break;
                case 7:
                    hex = "7" + hex;
                    break;
                case 8:
                    hex = "8" + hex;
                    break;
                case 9:
                    hex = "9" + hex;
                    break;
                case 10:
                    hex = "A" + hex;
                    break;
                case 11:
                    hex = "B" + hex;
                    break;
                case 12:
                    hex = "C" + hex;
                    break;
                case 13:
                    hex = "D" + hex;
                    break;
                case 14:
                    hex = "E" + hex;
                    break;
                case 15:
                    hex = "F" + hex;
                    break;
                default:
                    break;
            }

            decimal = decimal / 16;
        }

        System.out.println("The Hexadecimal value is  : " + hex);
    }
}
