package lottery;

import java.util.Scanner;

public class Lottery {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int randomNumber1=(int)(Math.random()*10),randomNumber2=(int)(Math.random()*10);
        System.out.println(randomNumber1+""+randomNumber2);
        int goldenNumber1,goldenNumber2;
        System.out.println("Give your first golden number");
        goldenNumber1=input.nextInt();
        System.out.println("Give me your second golden number");
        goldenNumber2=input.nextInt();
        if (goldenNumber1==randomNumber1 && goldenNumber2==randomNumber2){
            System.out.println("🎉🎉 Congratulation 🎉🎉 you won 10,000$");}
        else if (goldenNumber1==randomNumber1 || goldenNumber2==randomNumber2){
            System.out.println("🎉🎉 Congratulation 🎉🎉 you won 3,000$");}
        else if (goldenNumber1==randomNumber2 && goldenNumber2==randomNumber1){
            System.out.println("🎉🎉 Congratulation 🎉🎉 you won 1,000$");}
        else{System.out.println("SORRY you don't win try agine!!");}
        
    }
    
}
