package testcourse;

public class TestCourse {

    public static void main(String[] args) {
        Course course1 = new Course("Java Programming");

        course1.addStudent("Firdaws");
        course1.addStudent("Omar");
        course1.addStudent("Ahmad");
        course1.addStudent("Mohammad");
        course1.dropStudent("Firdaws");
        

        System.out.println("Course: " + course1.getCourseName());
        System.out.println("Number of Students: " + course1.getNumberOfStudents());

        String[] students = course1.getStudents();
        for (int i = 0; i < course1.getNumberOfStudents(); i++) {
            System.out.println((i + 1) + ". " + students[i]);
        }
    }
}