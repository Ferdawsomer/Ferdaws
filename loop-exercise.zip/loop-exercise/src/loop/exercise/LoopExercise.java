package loop.exercise;

import java.util.Scanner;

public class LoopExercise {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int num1, num2, sum, answer;
        num1 = (int) (Math.random() * 100);
        num2 = (int) (Math.random() * 100);
        System.out.println("What is the result of :-   " + num1 + "+" + num2);
        sum = num1 + num2;
        answer = input.nextInt();
        while (sum != answer) {
            System.out.println("Your answer is wrong! Please try again ");
            answer = input.nextInt();
        }
        System.out.println("Your answer is correct!");

    }

}
