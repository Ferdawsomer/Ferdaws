package bim;

import java.util.Scanner;

public class BIM {
    public static void main(String[] args) {
        Scanner input=new Scanner(System.in);
        double weight;
        System.out.println("Give me your weight!");
        weight = input.nextDouble();
        
        if (weight>=30.0){System.out.println("You are Obese");}
        else if (weight>=25.0){System.out.println("You are OverWeight");}
        else if (weight>=18.5){System.out.println("You are NormalWeight");}
        else if (weight<18.5){System.out.println("You are UnderWeight");}

        

        
        
    }
    
}
