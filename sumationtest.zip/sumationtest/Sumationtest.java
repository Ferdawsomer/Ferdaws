package sumationtest;

import java.util.Scanner;

public class Sumationtest {
    public static void main(String[] args) {
        Scanner input=new Scanner (System.in);
        int num1=(int)(Math.random()*10),num2=(int)(Math.random()*10),R,r;
        R=num1+num2;
        System.out.println("What is the answer of   "+num1+"+"+num2+"?");
        r=input.nextInt();
        
        if(R==r){System.out.println("You answer is correct!");}
        else {System.out.println("Your answer isn't correct!");}
        

        
    }
    
}
