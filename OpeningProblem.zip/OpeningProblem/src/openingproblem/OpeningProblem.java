package openingproblem;

public class OpeningProblem {

    public static void main(String[] args) {
        int[] numbers = new int[100];
        int total = 0;
        int counter = 0;
        for (int i = 0; i < 100; i++) {
            numbers[i] = (int) (Math.random() * 10);
            System.out.print(" " + numbers[i]);
            total += numbers[i];
        }
        System.out.println();
        System.out.println("Total = " + total);
        int ave = total / numbers.length;
        System.out.println("average = " + ave);
        for (int i = 0; i < 100; i++) {
            if (numbers[i] > ave) {
                counter++;
                System.out.println(numbers[i]);
            }
        }
        System.out.println("amount of numbers that are large then average " + counter);

    }

}
