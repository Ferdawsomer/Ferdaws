package leapyear;

import java.util.Scanner;

public class Leapyear {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int year;
        System.out.println("Give me the year");
        year = input.nextInt();

        if ((year % 4 == 0 && year % 100 != 0) || (year % 400 == 0)) {
            System.out.println("true");
        } else {
            System.out.println("false");
        }
    }

}
