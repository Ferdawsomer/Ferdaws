
package ferdawsomerwardak;

/**
 *
 * @author FIRDAUS
 */
public class FerdawsOmerWardak {

    public static void main(String[] args) {
        System.out.println("My name is Ferdaws, my father’s name Abdulbasir, my last name is Samadi. I have one brother and his name is Nangyaly, he is a doctor. My father is an engineer. I graduated from Mir Gholam Mohammad Ghobar high school, and now I study in university of Kabul AFG, Computer Sienese IT (information technology). I was a teacher in the 10th,11th class teaching English language in on of a center by the name of Adalat educational center, and I was the teacher of Islamic books also. I want to become in the future a good IT man and serve to my country."
              
                )
               
    }
    
}
