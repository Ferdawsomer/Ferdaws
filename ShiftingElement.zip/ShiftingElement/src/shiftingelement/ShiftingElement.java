package shiftingelement;

public class ShiftingElement {

    public static void main(String[] args) {
        int[] list = new int[5];

        list[0] = 1;
        list[1] = 2;
        list[2] = 3;
        list[3] = 4;
        list[4] = 5;
        
        int temp = list[0];
        for (int i = 1; i < 5; i++) {
            list[i-1] = list[i];
        }
        list[list.length-1] = temp;
        for (int i = 0; i < 5; i++) {
            System.out.print(list[i]);
        }
        System.out.println();
    }

}
