package chinesezodiac;

import java.util.Scanner;

public class ChineseZodiac {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int year;
        System.out.println("Give me the year!");
        year = input.nextInt();

        switch (year % 12) {
            case 0:
                System.out.println("The monkey year!");
                break;
            case 1:
                System.out.println("The rooster year!");
                break;
            case 2:
                System.out.println("The dog year!");
                break;
            case 3:
                System.out.println("The pig year!");
                break;

            case 4:
                System.out.println("The rat year!");
                break;

            case 5:
                System.out.println("The ox year!");
                break;

            case 6:
                System.out.println("The tiger year!");
                break;

            case 7:
                System.out.println("The rabbit year!");
                break;

            case 8:
                System.out.println("The dragon year!");
                break;

            case 9:
                System.out.println("The snake year!");
                break;

            case 10:
                System.out.println("The horse year!");
                break;

            case 11:
                System.out.println("The sheep year!");
            default:System.out.println("!");
        }
        

    }

}
